﻿namespace Utilities.API.Model.DBModel
{
    public class Payment
    {
        public string[] payment_type { get; set; }

    }
}
