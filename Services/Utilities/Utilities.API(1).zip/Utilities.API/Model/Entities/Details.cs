﻿namespace Utilities.API.Model.Entities
{
    public class Details
    {
        public string? kind { get; set; }
        public string? target { get; set; }
        public Message? message { get; set; }
    }
}
