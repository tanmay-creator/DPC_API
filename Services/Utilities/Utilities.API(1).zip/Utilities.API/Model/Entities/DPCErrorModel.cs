﻿namespace Utilities.API.Model.Entities
{
    public class DPCErrorModel
    {
        public Error error { get; set; }
    }
}
