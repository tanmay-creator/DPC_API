using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.EntityFrameworkCore;
using System.Text.Json.Serialization;
using Utilities.API;
using Utilities.API.ExceptionMiddleware;
using Serilog;

var builder = WebApplication.CreateBuilder(args);
var tenantId = Environment.GetEnvironmentVariable("AZURE_TENANT_ID");
var clientId = Environment.GetEnvironmentVariable("AZURE_CLIENT_ID");
var clientSecret = Environment.GetEnvironmentVariable("AZURE_CLIENT_SECRET");
var keyVaultUrl = Environment.GetEnvironmentVariable("KEY_VAULT_URL");
var appConfigUrl = Environment.GetEnvironmentVariable("APP_CONFIGURATION_URL");
// Add services to the container.

builder.Services.AddControllers()
      .AddJsonOptions(options =>
      {
          options.JsonSerializerOptions.PropertyNamingPolicy = null;
          options.JsonSerializerOptions.WriteIndented = true;
      });

//----------------------------------Key Vault------------------------------------------------------------------------------------
// Install-package Azure.Security.KeyVault.Secrets

var client = new SecretClient(new Uri(keyVaultUrl), /*new ClientSecretCredential(tenantId, clientId, clientSecret)*/ new DefaultAzureCredential());
KeyVaultSecret DbSecret = client.GetSecret("ConnectionStrings--DefaultConnection");


KeyVaultSecret RedisSecret = client.GetSecret("ConnectionStrings--RedisConnectionString");
string SqlConnectionString = DbSecret.Value;
string RedisConnectionString = RedisSecret.Value;

var config = new ConfigurationBuilder()
            .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
            .AddJsonFile("appsettings.json")
            .Build()
            .Get<Config>();
config.RedisURL = RedisConnectionString;

var jsonWriteOptions = new JsonSerializerOptions()
{
    WriteIndented = true
};
jsonWriteOptions.Converters.Add(new JsonStringEnumConverter());

var newJson = System.Text.Json.JsonSerializer.Serialize(config, jsonWriteOptions);
Console.WriteLine(newJson);
var appSettingsPath = Path.GetFullPath("appsettings.json");
File.WriteAllText(appSettingsPath, newJson);

builder.Services.AddSingleton<AzureADLSDetails>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IRedisCache, RedisCache>();

builder.Services.AddHttpContextAccessor();
builder.Services.AddDbContext<ApplicationDbContext>
        (options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
//(options => options.UseSqlServer(builder.Configuration.GetConnectionString(SqlConnectionString)));

Log.Logger = new LoggerConfiguration()
.MinimumLevel.Information()
.WriteTo.Console()
.CreateLogger();
builder.Logging.AddSerilog();

builder.Services.AddApiVersioning(config =>
{
    config.DefaultApiVersion = new ApiVersion(1, 0);
    config.AssumeDefaultVersionWhenUnspecified = true;
    config.ReportApiVersions = true;
    config.ApiVersionReader = new UrlSegmentApiVersionReader();
});

builder.Services.AddVersionedApiExplorer(setup =>
{
    setup.GroupNameFormat = "'v'VVV";
    setup.SubstituteApiVersionInUrl = true;
});




var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ExceptionHandlingMiddleware>();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
