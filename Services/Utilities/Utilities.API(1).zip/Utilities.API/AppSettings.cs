﻿namespace Utilities.API
{
    public class AzureADLSDetails
    {
        public string AzureBlobConnectionString { get; set; }
        public string AzureBlobContainerName { get; set; }
        public string FundingAccountJsonSchema { get; set; }
        public string StorageAccountName { get; set; } = "dpcadlsaccount";
        public string ServicePrincipalClientId { get; set; } = "12e3fca8-695e-4e27-a2df-93f7869ff1c9";
        public string ServicePrincipalClientSecret { get; set; } = "oqJ8Q~9JlmcFKB-nM8x7UKPHHH0wWRaOBDunkdlu";
        public string FileSystemName { get; set; } = "dpccontainer";
        public string DirectoryName { get; set; } = "Schemas";
        public string TenantId { get; set; } = "b4feb9b5-d957-4fbc-ae8c-781121f3fe1e";

        public double CountryListExpirationTime { get; set; } = 5.0;
        //public string SchemaFileName { get; set; } = "FundingSchema.json";
    }

}
