﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Reflection.Metadata;
using System.Text;
using UserProfile.API.Application.ModelDTOs.v1.UserProfile.Request;
using UserProfile.API.Application.ModelDTOs.v1.UserProfile.Response;
using UserProfile.API.Application.Services.v1.Services.Abstraction;
using UserProfile.API.Domain.Exceptions;
using UserProfile.API.UserProfile_Schema.Model.ValidationErrorModels;

namespace UserProfile.API.Controllers.v1
{
    //[Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [ApiVersion("1")]
    //[ApiVersion("1.0")]
    //[ApiVersion("2.0")]
    public class UserProfileController : Controller
    {
        #region Variables

        private readonly IUserProfileService _userprofileService;
        private readonly IUtilityService _utilityService;
        private readonly ILogger<UserProfileController> _logger;

        #region UserProfileVariables
        private HttpResponseMessage _userProfileReqValidation;
        private HttpResponseMessage _userProfileResValidation;
        private HttpResponseMessage _userProfileResponse;
        private string _userProfileReqValidationContent;
        private string _userProfileResValidationContent;
        private string _userProfileResponseContent;
        private const string _userProfileCreate_ReqSchemaName = "UserProfile/UserProfileCreate_RequestSchema.json";
        private const string _userProfileCreate_ResSchemaName = "UserProfile/UserProfileCreate_ResponseSchema.json";
        private const string _userProfileUpdate_ReqSchemaName = "UserProfile/UserProfileUpdate_RequestSchema.json";
        private const string _commPrefUpdate_ReqSchemaName = "UserProfile/ComPrefUpdate_Schema.json";
        private const string _commPrefUpdate_ResSchemaName = "UserProfile/ComPrefUpdate_Schema.json";
        #endregion

        #endregion

        public AppSettings _appSettings { get; }

        public UserProfileController(IUserProfileService userprofileService, IUtilityService utilityService, ILogger<UserProfileController> logger, IOptionsSnapshot<AppSettings> appSettings)
        {
            _userprofileService = userprofileService;
            _logger = logger;
            _utilityService = utilityService;
            _logger = logger;
            _appSettings = appSettings.Value;
        }

        #region Create User Profile

        [HttpPost]
        //[Route("api/v{version:apiVersion}/[controller]/billers/active/{biller-id}/{lob-name}")]
        [Route("CreateUserProfile")]

        public async Task<IActionResult> CreateUserProfile()
        {
            try
            {
                _logger.LogInformation("UserProfileController :: Request for creating user profile  has started for the user");
                string userProfileBody = string.Empty;
                var reader = new StreamReader(Request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false);
                userProfileBody = await reader.ReadToEndAsync();
                JObject data = JObject.Parse(userProfileBody);

                // Request validation
                _userProfileReqValidation = await _utilityService.ValidateRequestResponse(userProfileBody, _userProfileCreate_ReqSchemaName);
                _userProfileReqValidationContent = await _userProfileReqValidation.Content.ReadAsStringAsync();

                if (_userProfileReqValidation.StatusCode == HttpStatusCode.OK)
                {
                    UserProfile_Request_DTO userProfileRequest_Dto = JsonConvert.DeserializeObject<UserProfile_Request_DTO>(userProfileBody);
                    _userProfileResponse = await _userprofileService.CreateUserProfile<HttpResponseMessage>(userProfileRequest_Dto);
                    _userProfileResponseContent = await _userProfileResponse.Content.ReadAsStringAsync();

                    // Successful user profile creation
                    if (_userProfileResponse.StatusCode == HttpStatusCode.OK)
                    {
                        // Response validation
                        _userProfileResValidation = await _utilityService.ValidateRequestResponse(_userProfileResponseContent, _userProfileCreate_ResSchemaName);
                        _userProfileResValidationContent = await _userProfileResValidation.Content.ReadAsStringAsync();

                        if (_userProfileResValidation.StatusCode == HttpStatusCode.OK)
                        {
                            UserProfile_Response_DTO _userProfileResponse_Dto = JsonConvert.DeserializeObject<UserProfile_Response_DTO>(_userProfileResponseContent);
                            _logger.LogInformation("UserProfileController::User Profile created successfully.");
                            return new ObjectResult(_userProfileResponse_Dto);
                        }
                        else if (_userProfileResValidation.StatusCode == HttpStatusCode.UnprocessableEntity)
                        {
                            RootError resValidationErrors = JsonConvert.DeserializeObject<RootError>(_userProfileResValidationContent);
                            return StatusCode(422, resValidationErrors);
                        }
                        else
                        {
                            var errorResponse = new ObjectResult(_userProfileResValidationContent);
                            errorResponse.StatusCode = (int)_userProfileResValidation.StatusCode;
                            return errorResponse; ;
                        }
                    }
                    else
                    {
                        var errorResponse = new ObjectResult(_userProfileResponseContent);
                        errorResponse.StatusCode = (int)_userProfileResponse.StatusCode;
                        return errorResponse; ;
                    }
                }
                // Request is not valid
                else
                {
                    RootError reqValidationErrors = JsonConvert.DeserializeObject<RootError>(_userProfileReqValidationContent);
                    return StatusCode(422, reqValidationErrors);
                }
            }
            catch (HttpRequestException ex)
            {
                throw new ServiceNotAvailableException(_vendorCode, _lobCode);
            }
            catch (JsonReaderException ex)
            {
                throw new BadRequestException(_vendorCode, _lobCode);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        #region Get User Profile

        [HttpGet]
        //[Route("api/v{version:apiVersion}/[controller]/billers/active/{biller-id}/{lob-name}")]
        [Route("GetUserProfile/{profile_id}")]
        public async Task<IActionResult> GetUserProfile(string profile_id)
        {

            try
            {
                _logger.LogInformation("UserProfileController::GetUserProfile called for profile id : {profile_id}  ", profile_id);
                _userProfileResponse = await _userprofileService.GetUserProfile<HttpResponseMessage>(profile_id);
                _userProfileResponseContent = await _userProfileResponse.Content.ReadAsStringAsync();

                if (_userProfileResponse.IsSuccessStatusCode)
                {
                    _logger.LogInformation("UserProfileController::User profile fetched successfully");
                    UserProfile_Response_DTO userProfile = JsonConvert.DeserializeObject<UserProfile_Response_DTO>(_userProfileResponseContent);
                    return Ok(userProfile);
                }
                else
                {
                    var errorResponse = new ObjectResult(_userProfileResponseContent);
                    errorResponse.StatusCode = (int)_userProfileResponse.StatusCode;
                    return errorResponse;
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation("UserProfileController::Following exception occurred in GetUserProfile  \n" + ex.ToString());
                throw;
            }

        }


        #endregion


        #region Update User Profile

        [HttpPatch]
        //[Route("api/v{version:apiVersion}/profiles/{profile_id}")]
        //[Route("api/v{version:apiVersion}/[controller]/billers/active/{biller-id}/{lob-name}")]
        [Route("UpdateUserProfile")]
        public async Task<IActionResult> UpdateUserProfile(string profileId)
        {
            try
            {
                _logger.LogInformation("UserProfileController::UpdateUserProfile called for given profile id : ");

                string userProfileBody = string.Empty;
                var reader = new StreamReader(Request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false);
                userProfileBody = await reader.ReadToEndAsync();

                // Request validation
                _userProfileReqValidation = await _utilityService.ValidateRequestResponse(userProfileBody, _userProfileUpdate_ReqSchemaName);
                _userProfileReqValidationContent = await _userProfileReqValidation.Content.ReadAsStringAsync();

                if (_userProfileReqValidation.StatusCode == HttpStatusCode.OK)
                {
                    UserProfile_Request_DTO userProfileRequest_Dto = JsonConvert.DeserializeObject<UserProfile_Request_DTO>(userProfileBody);
                    _userProfileResponse = await _userprofileService.UpdateUserProfile<HttpResponseMessage>(profileId, userProfileRequest_Dto);
                    _userProfileResponseContent = await _userProfileResponse.Content.ReadAsStringAsync();

                    // Successful user profile creation
                    if (_userProfileResponse.StatusCode == HttpStatusCode.OK)
                    {
                        // Response validation
                        _userProfileResValidation = await _utilityService.ValidateRequestResponse(_userProfileResponseContent, _userProfileCreate_ResSchemaName);
                        _userProfileResValidationContent = await _userProfileResValidation.Content.ReadAsStringAsync();

                        if (_userProfileResValidation.StatusCode == HttpStatusCode.OK)
                        {
                            UserProfile_Response_DTO _userProfileResponse_Dto = JsonConvert.DeserializeObject<UserProfile_Response_DTO>(_userProfileResponseContent);
                            _logger.LogInformation("UserProfileController::User Profile updated successfully.");
                            return new ObjectResult(_userProfileResponse_Dto);
                        }
                        else if (_userProfileResValidation.StatusCode == HttpStatusCode.UnprocessableEntity)
                        {
                            var errors = JsonConvert.DeserializeObject<RootError>(_userProfileResValidationContent);
                            return StatusCode(422, errors);
                        }
                        else
                        {
                            var errorResponse = new ObjectResult(_userProfileResValidationContent);
                            errorResponse.StatusCode = (int)_userProfileResValidation.StatusCode;
                            return errorResponse; ;
                        }
                    }
                    else
                    {
                        var errorResponse = new ObjectResult(_userProfileResponseContent);
                        errorResponse.StatusCode = (int)_userProfileResponse.StatusCode;
                        return errorResponse; ;
                    }
                }
                // Request is not valid
                else
                {
                    var errors = JsonConvert.DeserializeObject<RootError>(_userProfileReqValidationContent);
                    return StatusCode(422, errors);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("UserProfileController::Following exception occurred in UpdateUserProfile " + ex.ToString());
                throw;
            }
        }
        #endregion

        #region Update Communication Preferences

        [HttpPatch]
        //[Route("api/v{version:apiVersion}/profiles/{profile_id}")]
        //[Route("/v{version:apiVersion}/user-profile/communication-preferences/{profile-id}/{kind}")]
        [Route("UpdateCommunicationPreferences/{profile-id}/{kind}")]
        public async Task<IActionResult> UpdateCommunicationPreferences([FromRoute(Name = "profile-id")] string profileId, [FromRoute(Name = "kind")] string kind)
        {
            try
            {
                _logger.LogInformation("UserProfileController::Update communication preferences called for given profile id and kind: ");

                string commPrefBody = string.Empty;
                var reader = new StreamReader(Request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false);
                commPrefBody = await reader.ReadToEndAsync();

                // Request validation
                _userProfileReqValidation = await _utilityService.ValidateRequestResponse(commPrefBody, _commPrefUpdate_ReqSchemaName);
                _userProfileReqValidationContent = await _userProfileReqValidation.Content.ReadAsStringAsync();

                if (_userProfileReqValidation.StatusCode == HttpStatusCode.OK)
                {
                    CommunicationPreference_Request_DTO comPrefRequest = JsonConvert.DeserializeObject<CommunicationPreference_Request_DTO>(commPrefBody);
                    _userProfileResponse = await _userprofileService.UpdateCommunicationPreferences<HttpResponseMessage>(profileId, comPrefRequest);
                    _userProfileResponseContent = await _userProfileResponse.Content.ReadAsStringAsync();

                    // Successful user profile creation
                    if (_userProfileResponse.StatusCode == HttpStatusCode.OK)
                    {
                        // Response validation
                        _userProfileResValidation = await _utilityService.ValidateRequestResponse(_userProfileResponseContent, _commPrefUpdate_ResSchemaName);
                        _userProfileResValidationContent = await _userProfileResValidation.Content.ReadAsStringAsync();

                        if (_userProfileResValidation.StatusCode == HttpStatusCode.OK)
                        {
                            CommunicationPreference_Response_DTO comPrefResponse = JsonConvert.DeserializeObject<CommunicationPreference_Response_DTO>(_userProfileResponseContent);
                            _logger.LogInformation("UserProfileController::User Profile updated successfully.");
                            return new ObjectResult(comPrefResponse);
                        }
                        else if (_userProfileResValidation.StatusCode == HttpStatusCode.UnprocessableEntity)
                        {
                            var errors = JsonConvert.DeserializeObject<RootError>(_userProfileResValidationContent);
                            return StatusCode(422, errors);
                        }
                        else
                        {
                            var errorResponse = new ObjectResult(_userProfileResValidationContent);
                            errorResponse.StatusCode = (int)_userProfileResValidation.StatusCode;
                            return errorResponse; ;
                        }
                    }
                    else
                    {
                        var errorResponse = new ObjectResult(_userProfileResponseContent);
                        errorResponse.StatusCode = (int)_userProfileResponse.StatusCode;
                        return errorResponse; ;
                    }
                }
                // Request is not valid
                else
                {
                    var errors = JsonConvert.DeserializeObject<RootError>(_userProfileReqValidationContent);
                    return StatusCode(422, errors);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("UserProfileController::Following exception occurred in UpdateUserProfile " + ex.ToString());
                throw;
            }
        }
        #endregion
    }
}
