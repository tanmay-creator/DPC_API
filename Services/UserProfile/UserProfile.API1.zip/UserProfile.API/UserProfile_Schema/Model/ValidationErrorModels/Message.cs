﻿namespace UserProfile.API.UserProfile_Schema.Model.ValidationErrorModels
{
    public class Message
    {
        public string @default { get; set; }

        public string code { get; set; }
    }
}
