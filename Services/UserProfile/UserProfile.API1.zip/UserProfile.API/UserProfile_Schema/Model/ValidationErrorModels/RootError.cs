﻿namespace UserProfile.API.UserProfile_Schema.Model.ValidationErrorModels
{
    public class RootError
    {
        public Error error { get; set; }
    }
}
