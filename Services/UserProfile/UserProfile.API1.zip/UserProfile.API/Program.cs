using Azure.Identity;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using UserProfile.API;
using UserProfile.API.Application.Services.v1.Services.Abstraction;
using UserProfile.API.Application.Services.v1.UserProfileService;
using UserProfile.API.Application.Services.v1.UtilitiesService;
using UserProfile.API.Domain.Repositories;
using UserProfile.API.Infrastructure;
using UserProfile.API.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
//builder.Services.Configure<AppSettings>(builder.Configuration);
//builder.Services.AddApiVersioning(config =>
//{
//    config.DefaultApiVersion = new ApiVersion(1, 0);    
//    config.AssumeDefaultVersionWhenUnspecified = true;
//    config.ReportApiVersions = true;
//});


//builder.Services.AddSingleton<ConnectionMultiplexer>(sp =>
//{
//    var settings = sp.GetRequiredService<IOptions<AppSettings>>().Value;
//    var configuration = ConfigurationOptions.Parse(settings.RedisConnectionString, true);

//    return ConnectionMultiplexer.Connect(configuration);
//});


//By connecting here we are making sure that our service
//cannot start until redis is ready. This might slow down startup,
//but given that there is a delay on resolving the ip address
//and then creating the connection it seems reasonable to move
//that cost to startup instead of having the first request pay the
//penalty.

//builder.Services.AddCustomHealthCheck(Configuration);

//........................................Key Vault...........................................................................
// For accessing secret (DB connection string) from azure key vault using system assigned managed identity

// Install-package Azure.Security.KeyVault.Secrets
// For using user assigned managed identity, pass this UAManagedIdentityClientId in DefaultAzureCredential()
//string UAManagedIdentityClientId = Environment.GetEnvironmentVariable("AZURE_CLIENT_ID");
//string UAManagedIdentityClientId = "75c47897-df76-40c4-b322-0e7a0216b203";
var tenantId = Environment.GetEnvironmentVariable("AZURE_TENANT_ID");
var clientId = Environment.GetEnvironmentVariable("AZURE_CLIENT_ID");
var clientSecret = Environment.GetEnvironmentVariable("AZURE_CLIENT_SECRET");
//var kvUri = "https://dpcrefapp-keyvault.vault.azure.net/";

//SecretClientOptions options = new SecretClientOptions()
//{
//    Retry =
//        {
//            Delay= TimeSpan.FromSeconds(2),
//            MaxDelay = TimeSpan.FromSeconds(16),
//            MaxRetries = 5,
//            Mode = RetryMode.Exponential
//         }
//};
//var client = new SecretClient(new Uri(kvUri), /*new ClientSecretCredential(tenantId, clientId, clientSecret)*/ new DefaultAzureCredential());
////SqlDBContainerConnString, SqlDBLocalConnString
//KeyVaultSecret DbSecret = client.GetSecret("SqlDBContainerConnString");
//string DbConnectionString = DbSecret.Value;
//Console.WriteLine("\n**********Secret from azure key vault is:-  " + DbConnectionString + "\n");



//........................................Azure App Configuration.................................................................
// For Azure App Config (using app service and system assigned managed identity)
// This code is by using service principle whose creadentials are stored in launchsettings.json
// Packages: Microsoft.Extensions.Configuration.AzureAppConfiguration, Azure.Identity
builder.Configuration.AddAzureAppConfiguration(o =>
{
    // Running on app service: endpoint
    o.Connect(new Uri("https://dpcrefapp-appconfiguration.azconfig.io"), new DefaultAzureCredential())
    .Select("ACICredentials:*", LabelFilter.Null)
    // Configure to reload configuration if the registered sentinel key is modified
    .ConfigureRefresh(refreshOptions => refreshOptions.Register("UserProfile:Settings:Sentinel", refreshAll: true).SetCacheExpiration(TimeSpan.FromSeconds(10))); ;


    // Running locally : connection string 
    //o.Connect("Endpoint=https://dpcrefapp-appconfiguration.azconfig.io;Id=rCDh;Secret=62nHYUf5j/hWsvaC5lJLh17cAgb2E1G1v06VsOaK5ko=")
    //.Select("ACICredentials:*", LabelFilter.Null)
    //// Configure to reload configuration if the registered sentinel key is modified
    //.ConfigureRefresh(refreshOptions => refreshOptions.Register("UserProfile:Settings:Sentinel", refreshAll: true).SetCacheExpiration(TimeSpan.FromSeconds(10)));
});

// Add Azure App Configuration middleware to the container of services.
builder.Services.AddAzureAppConfiguration();
builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("ACICredentials"));
builder.Services.AddHttpClient<IUserProfileService, UserProfileService>();
builder.Services.AddScoped<IUserProfileService, UserProfileService>();
builder.Services.AddHttpClient<IUtilityService, UtilitiesService>();
builder.Services.AddScoped<IUtilityService, UtilitiesService>();
builder.Services.AddScoped<IUserProfileRepository, UserProfileRepository>();
builder.Services.AddDbContext<RepositoryDBContext>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ExceptionHandlingMiddlewarecs>();
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
