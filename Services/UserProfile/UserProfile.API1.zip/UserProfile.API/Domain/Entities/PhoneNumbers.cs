﻿namespace UserProfile.API.Domain.Entities
{
    public class PhoneNumbers
    {
        public PhoneNumber [] phoneNumber { get; set; } 
    }
}
