﻿namespace UserProfile.API.Domain.Entities
{
    public class Details
    {
        public string kind { get; set; }
        public string target { get; set; }
        public Message message { get; set; }
    }
}
