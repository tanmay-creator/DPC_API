﻿namespace UserProfile.API.Domain.Entities
{
    public class EnabledNotifications
    {
        //public NotificationKinds notificationKinds { get; set; } 
       public NotificationKinds notificationKinds;
    }
}
