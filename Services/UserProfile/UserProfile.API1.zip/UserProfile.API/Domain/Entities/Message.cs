namespace UserProfile.API.Domain.Entities
{
    public class Message
    {
        public string? code { get; set; }
        public string? description { get; set; }

        
    }
}
