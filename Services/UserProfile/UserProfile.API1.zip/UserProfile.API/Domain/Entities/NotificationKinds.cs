﻿namespace UserProfile.API.Domain.Entities
{
    public class  NotificationKinds
    {
        enum NotificationKind
        {
            PaymentDue,
            PaymentConfirmation
        }
        
        
    }
}
