namespace UserProfile.API.Domain.Entities
{
    public class DPCErrorModel
    {
        public Error error { get; set; }
    }
}
