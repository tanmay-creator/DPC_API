﻿namespace UserProfile.API.Infrastructure.Model
{
    public class UserProfile_DBModel
    {
        public Guid UserProfileId { get; set; }
    }
}
