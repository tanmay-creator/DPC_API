﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Text;
using UserProfile.API.Application.Services.v1.Services.Abstraction;
using static UserProfile.API.Application.Services.v1.APIEndpoint;

namespace UserProfile.API.Application.Services.v1.UtilitiesService
{

    internal sealed class UtilitiesService : IUtilityService
    {
        #region Variables
        private readonly HttpClient _apiClient;
        private readonly ILogger<UtilitiesService> _logger;
        private readonly string _utilityServiceBaseUrl;
        private HttpResponseMessage validationResponse;
        public AppSettings _appSettings { get; }
        #endregion


        public UtilitiesService(HttpClient httpClient, ILogger<UtilitiesService> logger, IOptionsSnapshot<AppSettings> appSettings)
        {
            _apiClient = httpClient;
            _logger = logger;
            _appSettings = appSettings.Value;
            _utilityServiceBaseUrl = _appSettings.UtilityServiceBaseUrl;
        }

        #region Validate Request Response
        public async Task<HttpResponseMessage> ValidateRequestResponse(string jsonRequest, string schemaName)
        {

            _logger.LogInformation("UtilityService:: Calling utility api for  validation");
            var utilityUrl = UserProfileEndpoint.ValidateRequestResponse(_utilityServiceBaseUrl, schemaName);
            HttpContent content = new StringContent(JsonConvert.SerializeObject(jsonRequest), Encoding.UTF8, "application/json");
            validationResponse = await _apiClient.PostAsync(utilityUrl, content);
            return validationResponse;

        }
        #endregion
    }
}
