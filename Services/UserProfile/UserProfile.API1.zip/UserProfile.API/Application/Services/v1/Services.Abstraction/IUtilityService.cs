﻿namespace UserProfile.API.Application.Services.v1.Services.Abstraction
{
    public interface IUtilityService
    {
        Task<HttpResponseMessage> ValidateRequestResponse(string jsonRequest, string schemaName);
    }
}
