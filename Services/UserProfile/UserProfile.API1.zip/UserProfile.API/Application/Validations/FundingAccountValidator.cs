﻿//using FluentValidation;
//using FundingAccount.API.Application.ModelDTOs.Request.FundingAccount.Unregistered;

//namespace FundingAccount.API.Application.Validations
//{
//    public class FundingAccountValidator : AbstractValidator<Unreg_FA_ACH_Request_DTO>
//    {
//        public FundingAccountValidator()
//        {
//            RuleFor(p => p.brandKind).NotEmpty()
//                .WithErrorCode("Branch Kind").WithMessage("Branch Kind cannot be Empty");
            
           
//        }
//    }
//}
