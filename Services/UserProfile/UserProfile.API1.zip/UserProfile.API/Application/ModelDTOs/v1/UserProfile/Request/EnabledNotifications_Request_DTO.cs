﻿namespace UserProfile.API.Application.ModelDTOs.v1.UserProfile.Request
{
    public record EnabledNotifications_Request_DTO
    {
        //public NotificationKinds notificationKinds { get; set; } 
        // public NotificationKinds notificationKinds;
    }
}
