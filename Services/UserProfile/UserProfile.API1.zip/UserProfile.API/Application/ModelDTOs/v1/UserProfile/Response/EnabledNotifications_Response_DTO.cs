﻿namespace UserProfile.API.Application.ModelDTOs.v1.UserProfile.Response
{
    public record EnabledNotifications_Response_DTO
    {
        //public NotificationKinds notificationKinds { get; set; } 
        //public NotificationKinds_Response_DTO notificationKinds;
    }
}
